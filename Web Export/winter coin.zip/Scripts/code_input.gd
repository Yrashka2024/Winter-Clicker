extends LineEdit

var target_text: String = "FGFRW"

func _text_changed(new_text: String) -> void:
 # Обрезаем текст, если он длиннее target_text
 if new_text.length() > target_text.length():
  text = new_text.substr(0, target_text.length())
 else:
  text = new_text # Если текст не обрезается, присваиваем new_text

 # Проверяем текст после возможной обрезки
 if text == target_text:
  print('успех')
  text = ""  # Очищаем LineEdit после успеха
 else:
  print('не найдено')
