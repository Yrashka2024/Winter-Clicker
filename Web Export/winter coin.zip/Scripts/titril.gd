extends Control

@export var scroll_speed: float = 50.0  # Скорость прокрутки (пиксели в секунду)
@export var start_delay: float = 1.0    # Задержка перед началом прокрутки
@onready var credits_label: Label = $credits_label
var is_scrolling: bool = false

func _ready():
	reset_credits_position()
	await get_tree().create_timer(start_delay).timeout  # Ожидание перед началом прокрутки
	is_scrolling = true

func _process(delta: float) -> void:
	if is_scrolling:
		credits_label.position.y -= scroll_speed * delta
		# Останавливаем прокрутку, если титры полностью вышли за экран
		if credits_label.position.y + credits_label.size.y < 0:
			is_scrolling = false

func reset_credits_position():
	# Устанавливаем начальную позицию титров чуть ниже видимой области
	credits_label.position.y = size.y
