extends Control

const SAVE_FILE = "user://player_data.cfg"
const NAME_KEY = "player_name"

func _ready():
	var player_name = load_name()
	if player_name == "":
		show_name_input()
	else:
		start_game(player_name)

func show_name_input():
	$NamePrompt.text = "Как тебя зовут?"
	$NameInput.visible = true
	$SubmitButton.visible = true

func _on_submit_button_pressed() -> void:
	var player_name = $NameInput.text.strip_edges()  # Удаляем лишние пробелы
	if player_name != "":
		save_name(player_name)
		start_game(player_name)
	else:
		print("Пожалуйста, введите имя.")

func start_game(player_name: String):
	print("Добро пожаловать, ", player_name)
	get_tree().change_scene_to_file("res://Scripts/game.tscn")

	# Скрываем элементы ввода имени
	$NamePrompt.visible = false
	$NameInput.visible = false
	$SubmitButton.visible = false

func save_name(player_name: String) -> void:
	var config = ConfigFile.new()
	var error = config.load(SAVE_FILE)
	if error != OK:
		print("Создание нового файла сохранения.")

	config.set_value("player", NAME_KEY, player_name)
	config.save(SAVE_FILE)
	print("Имя сохранено: ", player_name)

func load_name() -> String:
	var config = ConfigFile.new()
	var error = config.load(SAVE_FILE)
	if error != OK:
		print("Файл сохранения не найден.")
		return ""  # Имя не сохранено, возвращаем пустую строку.

	var player_name = config.get_value("player", NAME_KEY, "")
	print("Загруженное имя: ", player_name)
	return player_name
