extends Node2D

var click = 0

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	load_click()
	$Label.text = str(click)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	$Label.text = str(click)

func _on_button_button_down() -> void:
	click += 1
	$"Snow".scale = Vector2(0.7, 0.7)
	save_click()

func _on_button_button_up() -> void:
	$"Snow".scale = Vector2(0.7, 0.5)

func save_click():
	var file = FileAccess.open("user://myfile.save", FileAccess.WRITE)
	if file:
		file.store_var(click)
		file.close()
		print("Game saved successfully!")
	else:
		print("Error opening file for saving!")

func load_click():
	var file = FileAccess.open("user://myfile.save", FileAccess.READ)
	if file:
		click = file.get_var(0)  # Читаем значение кликов. По умолчанию - 0.
		file.close()
		print("Game loaded successfully! Clicks: ", click)
	else:
		print("No save file found.")
