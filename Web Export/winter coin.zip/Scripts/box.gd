extends Node2D

# Количество кликов
var clicks: int = 0

# Массив с предметами
var items = [
	"Золотая монета",
	"Жизнь",
	"Эликсир здоровья",
	"Доспех",
	"Меч"
]

# Название сцены, куда возвращаться при недостатке кликов
@export var fallback_scene: String = "res://Scripts/menu.tscn"

func _ready():
	# Пример начального количества кликов (можно заменить на загрузку сохранённых данных)
	clicks = 150

func _on_texture_button_pressed() -> void:
	if clicks >= 100:
		clicks -= 100
		var random_item = get_random_item()
		print("Вам выпало: ", random_item)
		print("Осталось кликов: ", clicks)
	else:
		print("Недостаточно кликов. Возвращаемся в главное меню.")
		get_tree().change_scene_to_file(fallback_scene)

# Функция для получения случайного предмета
func get_random_item() -> String:
	return items[randi() % items.size()]
